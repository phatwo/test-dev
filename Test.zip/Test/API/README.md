Partie 2: Développement python (Back-End)
Exercice 1: API avec logique de filtrage
Pour lancer l'application ouvrer l'invite de commande le cmd ou n'importe quelle interface utilisateur
et placez-vous sur le dossier ici le dossier test après API.
Une fois placer sur le dossier MDC taper "python app.py" lancer doit se lancer.
Ouvrier enccore l'invite de commande le cmd ou n'importe quelle interface utilisateur placez-vous sur le dossier API et entre les endpoints
curl -X POST -H "Content-Type: application/json" -d "{\"numbers\": [1, 5, 6, 10, 3, 7, 12]}" http://127.0.0.1:5000/numbers
curl -X POST -H "Content-Type: application/json" -d "{\"a\": 25, \"b\": 40}" http://127.0.0.1:5000/sum
NB: j'utilise windows