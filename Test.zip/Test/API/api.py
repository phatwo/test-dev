from flask import Flask, request, jsonify

app = Flask(__name__)

# Endpoint /numbers
@app.route('/numbers', methods=['POST'])
def get_even_numbers():
    data = request.get_json()  
    if not data or 'numbers' not in data:
        return jsonify({"error": "Veuillez fournirS une liste de nombres."}), 400

    numbers = data['numbers']

    # Fi les nombres pairs
    even_numbers = [num for num in numbers if num % 2 == 0]

    return jsonify({"even_numbers": even_numbers})

# Endpoint /sum 
@app.route('/sum', methods=['POST'])
def sum_two_numbers():
    data = request.get_json()  # Récupérer les données en JSON
    if not data or 'a' not in data or 'b' not in data:
        return jsonify({"error": "Veuillez fournir deux nombres a et b."}), 400

    a = data['a']
    b = data['b']

    # Calculer la somme
    result = a + b

    return jsonify({"sum": result})

if __name__ == '__main__':
    app.run(debug=True)
