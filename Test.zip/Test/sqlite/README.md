Pour executer le script 
télécharger SQlite
lancer sqlite3
sqlite3 employees.db < init_employees.sql
