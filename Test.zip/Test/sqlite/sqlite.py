import sqlite3

# Connexion à la base de données SQLite (ou création si elle n'existe pas)
conn = sqlite3.connect('employees.db')

# Création d'un curseur pour exécuter les commandes SQL
cursor = conn.cursor()

# Création de la table 'employees' avec les champs 'name' et 'salary'
cursor.execute('''
CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    salary REAL NOT NULL
)
''')

# Insertion de données dans la table 'employees'
employees_data = [
    ('Amadou', 10000),
    ('Fatoumata', 30000),
    ('Aly', 60000),
    ('Aminata', 50000),
    ('Abdoulaye', 55000)
]

cursor.executemany('''
INSERT INTO employees (name, salary)
VALUES (?, ?)
''', employees_data)

# Sauvegarde des changements dans la base de données
conn.commit()

# Récupération et affichage des employés ayant un salaire supérieur à 50,000
cursor.execute('''
SELECT name, salary FROM employees WHERE salary > 50000
''')

# Affichage des résultats
high_salary_employees = cursor.fetchall()
print("Employés avec un salaire supérieur à 50,000 :")
for employee in high_salary_employees:
    print(f"Nom: {employee[0]}, Salaire: {employee[1]}")

# Fermeture de la connexion
conn.close()
