from flask import Flask, request, render_template

app = Flask(__name__, template_folder="html")

# liste des prénoms valides
prenoms_valides = []

# Route de l'application
@app.route("/", methods=["GET", "POST"])
def index():
    message = ""
    
    if request.method == "POST":
        # Récupérer le prénom depuis le formulaire
        prenom = request.form.get("prenom")
        
        # Vérifier que le prénom n'est pas None
        if prenom:
            prenom = prenom.strip()  # Enlever les espaces inutiles
            # Vérifier si le prénom commence par 'A'
            if prenom.startswith('A') or prenom.startswith('a'):
                message = f"{prenom} - Prénom valide"
                # Ajouter à la liste des prénoms valides
                prenoms_valides.append(prenom)
            else:
                message = f"{prenom} - Prénom invalide"
        else:
            message = "Veuillez entrer un prénom."
    
    return render_template("index.html", message=message, prenoms_valides=prenoms_valides)

if __name__ == "__main__":
    app.run(debug=True)
