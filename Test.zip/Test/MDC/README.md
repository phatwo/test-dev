Partie 2: Développement python (Back-end)
Exercice 2: Manipulation de données et condition 
Pour lancer l'application ouvrer l'invite de commande le cmd ou n'importe quelle interface utilisateur
et placez-vous sur le dossier ici le dossier test après MDC.
Une fois placer sur le dossier MDC taper "python app.py" lancer doit se lancer
Accéder à l'application sur le navigateur en tapant "http://127.0.0.1:5000".
la liste de prénoms utilisé: Aminata, Fatoumata, Amadou, Kadidia, Bouba, Moussa, Abdoulaye
NB: Dans l'application entre un prémier prénom et cliquez sur vérfifier et ainsi de suite.
NB: j'utilise Windows